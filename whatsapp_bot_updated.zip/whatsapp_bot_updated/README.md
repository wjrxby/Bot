<p align="center"> 
<a href="https://github.com/araab-zack"><img src="http://readme-typing-svg.herokuapp.com?font=mono&size=17&duration=4000&color=9e62d7&center=falso&vCenter=falso&lines=TheFlashBot-MD++%F0%9F%90%88;©+By+Mori+Dev+%F0%9F%92%96" height="90px"></a> 
<img src="https://files.catbox.moe/lej4g5.jpg" alt="MoriBot-MD" style="width: 100%; height: auto; max-width: 500px;">
  
> هذا المشروع مفتوح المصدر، لمزيد من المعلومات قم بزيارة **[سياسة فلاش بوت 📍](https://github.com/MoriCommunity/TheFlashBot-MD1/blob/master/terms.md)** 
</p>

<p align="center">
<a href="#"><img title="MoriBot-MD" src="https://img.shields.io/badge/IF YOU LIKE THE REPOSITORY, SUPPORT ME WITH A 🌟 THANK YOU! -red?colorA=%255ff0000&colorB=%23017e40&style=for-the-badge"></a> 
<img src="https://i.pinimg.com/originals/d4/3c/90/d43c902873d4db8c85974dfd0798030b.gif" height="28px">
</p>  

<p align="center">
<a href="#"><img title="MoriBot-MD" src="https://img.shields.io/badge/READ THE ENTIRE README-red?colorA=%F77F48FF&colorB=%F77F48FF&style=for-the-badge"></a> 
<a href="#"><img title="MoriBot-MD" src="https://img.shields.io/badge/ COMPATIBLE WITH MULTI-DEVICE VERSION OF WHATSAPP-red?colorA=%F77F48FF&colorB=%F77F48FF&style=for-the-badge"></a>
</p>

<p align="center">   
<a href="https://github.com/araab-zack/MoriBotRamadan-MD/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/araab-zack/MoriBotRamadan-MD?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/araab-zack/MoriBotRamadan-MD/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/araab-zack/MoriBotRamadan-MD?label=Stars&color=yellow&style=flat-square"></a>
</p>

<div align="center">
 
[![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:yto941395@gmail.com)
[![Support](https://img.shields.io/badge/Support-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/q1_1r)
[![WhatsApp](https://img.shields.io/badge/STAFF-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/201159106301)
[![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@v1_1q)
</div>

### 👇 `جميع التحديثات موجودة هنا!!`
[![الروابط](https://img.shields.io/badge/Mori-Channel-000000%7D?style=for-the-badge&logo=biolink&logoColor=white)](https://whatsapp.com/channel/0029Vb0WYOu2f3EAb74gf02h)
> منصه ميجا هوست لي رفع بوتك عليها مضمونة 100% **[Mega Hosting 📍](https://host.joanimi-world.site)** 
</p>

### 🆕 أهم مميزات هذا المشروع إطلع على الملخص!
<details>
  <summary><b>⭐ اضغط هنا</b></summary>

 <details>
  <summary><b>🐈 على MoriBot-MD</b></summary>
  
| مشكلة | وصف | اختصار |
|------|-------------|-------|
| 🔑 **المالكين** | *حدد من سيكون له السيطرة الكاملة على الروبوت* | [![اضغط هنا](https://img.shields.io/badge/Aquí-green)](https://github.com/araab-zack/MoriBotRamadan-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L15) |
| ✏️ **تعديل الاسم** | *تغيير اسم البوت بسهولة* | [![اضغط هنا](https://img.shields.io/badge/Aquí-green)](https://github.com/araab-zack/MoriBotRamadan-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L144) | 
| 📲 **الاتصال باستخدام الكود (اختياري)** | *قم بربط رقمك مباشرة لتلقي رمز مكون من 8 أرقام.* | [![اضغط هنا](https://img.shields.io/badge/Aquí-green)](https://github.com/araab-zack/MoriBotRamadan-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L44) |
