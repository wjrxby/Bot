process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1'
import './config.js' 
import './plugins/_content.js'
import { createRequire } from 'module'
import path, { join } from 'path'
import {fileURLToPath, pathToFileURL} from 'url'
import { platform } from 'process'
import * as ws from 'ws'
import fs, { watchFile, unwatchFile, writeFileSync, readdirSync, statSync, unlinkSync, existsSync, readFileSync, copyFileSync, watch, rmSync, readdir, stat, mkdirSync, rename, writeFile } from 'fs'
import yargs from 'yargs'
import { spawn } from 'child_process'
import lodash from 'lodash'
import chalk from 'chalk'
import syntaxerror from 'syntax-error'
import { format } from 'util'
import pino from 'pino'
import Pino from 'pino'
import { Boom } from '@hapi/boom'
import { makeWASocket, protoType, serialize } from './lib/simple.js'
import {Low, JSONFile} from 'lowdb'
import readline from 'readline'
import NodeCache from 'node-cache' 
import pkg from 'google-libphonenumber'
const { PhoneNumberUtil } = pkg
const phoneUtil = PhoneNumberUtil.getInstance()
const { makeInMemoryStore, DisconnectReason, useMultiFileAuthState, MessageRetryMap, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = await import('@whiskeysockets/baileys')
const { CONNECTING } = ws
const { chain } = lodash
const PORT = process.env.PORT || process.env.SERVER_PORT || 3000
protoType()
serialize()
global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') {
  return rmPrefix ? /file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL : pathToFileURL(pathURL).toString();
}; global.__dirname = function dirname(pathURL) {
  return path.dirname(global.__filename(pathURL, true));
}; global.__require = function require(dir = import.meta.url) {
  return createRequire(dir);
};
global.API = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({...query, ...(apikeyqueryname ? {[apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name]} : {})})) : '')
global.timestamp = { start: new Date }
const __dirname = global.__dirname(import.meta.url);
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
global.prefix = new RegExp('^[' + (opts['prefix'] || '*/i!#$%+£¢€¥^°=¶∆×÷π√✓©®&.\\-.@').replace(/[|\\{}()[\]^$+*.\-\^]/g, '\\$&') + ']')
//news
const databasePath = path.join(__dirname, 'database');
if (!fs.existsSync(databasePath)) fs.mkdirSync(databasePath);
const usersPath = path.join(databasePath, 'users');
const chatsPath = path.join(databasePath, 'chats');
const settingsPath = path.join(databasePath, 'settings');
const msgsPath = path.join(databasePath, 'msgs');
const stickerPath = path.join(databasePath, 'sticker');
const statsPath = path.join(databasePath, 'stats');
[usersPath, chatsPath, settingsPath, msgsPath, stickerPath, statsPath].forEach((dir) => {
if (!fs.existsSync(dir)) fs.mkdirSync(dir);
});
function getFilePath(basePath, id) {
return path.join(basePath, `${id}.json`);
}
global.db = {
data: {
users: {},
chats: {},
settings: {},
msgs: {},
sticker: {},
stats: {},
},
READ: false,
};
global.loadDatabase = async function loadDatabase() {
if (global.db.READ) {
return new Promise((resolve) => {
const interval = setInterval(() => {
if (!global.db.READ) {
clearInterval(interval);
resolve(global.db.data);
}}, 1000);
});
}
global.db.READ = true;
try {
const loadFiles = async (dirPath, targetObj, ignorePatterns = []) => {
const files = fs.readdirSync(dirPath);
for (const file of files) {
const id = path.basename(file, '.json');
if (ignorePatterns.some(pattern => id.includes(pattern))) {
continue; 
}
const db = new Low(new JSONFile(getFilePath(dirPath, id)));
await db.read();
targetObj[id] = db.data || {};
}};
await Promise.all([
loadFiles(usersPath, global.db.data.users, ['undefined']),
loadFiles(chatsPath, global.db.data.chats, []),
loadFiles(settingsPath, global.db.data.settings, []),
loadFiles(msgsPath, global.db.data.msgs, []),
loadFiles(stickerPath, global.db.data.sticker, []),
loadFiles(statsPath, global.db.data.stats, []),
]);
} catch (e) {
console.error(e);
} finally {
global.db.READ = false;
}};

// Create a new store instance
const waStore = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

const msgRetryCounterMap = MessageRetryMap || {}
const msgRetryCounterCache = new NodeCache()

async function startBot() {
const { state, saveCreds } = await useMultiFileAuthState('./MysticSession')
const { version, isLatest } = await fetchLatestBaileysVersion()
console.log(`Usando WA v${version.join('.')}, es la última: ${isLatest}`)

const connectionOptions = {
printQRInTerminal: true,
auth: {
creds: state.creds,
keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
},
logger: pino({ level: "fatal" }).child({ level: "fatal" }),
browser: ['FlashBot-MD', 'Safari', '1.0.0'],
version,
getMessage: async (key) => {
let jid = jidNormalizedUser(key.remoteJid)
let msg = await waStore.loadMessage(jid, key.id)
return msg?.message || ""
},
msgRetryCounterCache,
msgRetryCounterMap,
defaultQueryTimeoutMs: undefined,
}

global.conn = makeWASocket(connectionOptions)
waStore.bind(conn.ev)

// Eventos de conexión
conn.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect, qr } = update
if (connection === 'close') {
const shouldReconnect = lastDisconnect?.error instanceof Boom && lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut
console.log('Conexión cerrada debido a:', lastDisconnect?.error, 'Reconectando:', shouldReconnect)
if (shouldReconnect) {
startBot()
}
} else if (connection === 'open') {
console.log('¡Conexión abierta!')
}
})

// Guardar credenciales cuando se actualicen
conn.ev.on('creds.update', saveCreds)

// Manejar mensajes
conn.ev.on('messages.upsert', async (chatUpdate) => {
// Implementar lógica para manejar mensajes
})

// Cargar plugins
const pluginsFolder = path.join(__dirname, 'plugins')
const pluginFiles = fs.readdirSync(pluginsFolder).filter(file => file.endsWith('.js'))
for (const file of pluginFiles) {
try {
const plugin = await import(path.join(pluginsFolder, file))
if (typeof plugin.default === 'function') {
plugin.default(global.conn, { store: waStore })
}
} catch (e) {
console.error(`Error al cargar el plugin ${file}:`, e)
}
}

// Cargar base de datos
await global.loadDatabase()

// Guardar base de datos periódicamente
setInterval(async () => {
if (global.db.data) {
// Guardar cada objeto en su archivo correspondiente
const saveToFile = async (obj, basePath) => {
for (const [id, data] of Object.entries(obj)) {
const db = new Low(new JSONFile(getFilePath(basePath, id)))
db.data = data
await db.write()
}
}
await Promise.all([
saveToFile(global.db.data.users, usersPath),
saveToFile(global.db.data.chats, chatsPath),
saveToFile(global.db.data.settings, settingsPath),
saveToFile(global.db.data.msgs, msgsPath),
saveToFile(global.db.data.sticker, stickerPath),
saveToFile(global.db.data.stats, statsPath),
])
}
}, 60 * 1000) // Guardar cada minuto
}

startBot()
